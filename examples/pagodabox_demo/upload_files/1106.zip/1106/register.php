<html>
	<body>
		<form method="POST" action="register.php">
			Account <input type ="text" name="account"><br>
			Password <input type ="password" name="password"><br>
			Email <input type ="text" name="email"><br>
			<input type="submit" value="sign up">
		</form>
	</body>
<html>

<?php
	require_once('user.php');

	$account = $_POST['account'];
	$password = $_POST['password'];
	$email = $_POST['email'];
	
	$userObject = new User($account, $password);
	$userObject->email = $email;
	$userObject->upload();
	
	echo $account;
	echo $password;
	echo $email;

?>
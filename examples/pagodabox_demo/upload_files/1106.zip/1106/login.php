<?php
ob_start();
if(isset($_COOKIE['account'])) {
	echo 'hello '.$_COOKIE['account'];
}
else {
	echo '
	<html>
	<body>
		<form method="POST" action="login.php">
			Account <input type ="text" name="account"><br>
			Password <input type ="password" name="password"><br>
			<input type="submit" value="sign in">
		</form>
	</body>
	<html>
	';
}
?>
<?php	
	if(isset($_POST['account']) && isset($_POST['password']) ) {

		require_once('user.php');
		$account = $_POST['account'];
		$password = $_POST['password'];
		
		$userObject = new User($account, $password);
		$userObject->email = $email;
		$isLogin = $userObject->login();		
		if($isLogin==true) {
//			setcookie('email', $userObject->email, time()+24*60*60);
			setcookie('account', $userObject->account, time()+24*60*60);
			echo 'sucess.';						
		} else {
			echo 'fail.';	
		}	
	}
	ob_end_flush();
?>
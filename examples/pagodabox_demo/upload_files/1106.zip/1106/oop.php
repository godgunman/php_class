<?php 

require_once('utility.php');

class User {

	public $uid;
	public $account;
	public $email;
	private $password;

	function __construct($account, $password){
	
		if(isset($password) && $password!='') {
			$this->password = $password;
		} else {
			$this->genPassword();
		}
		$this->account = $account;
	}
	
	public function genPassword() {	
		$this->password = rand(10000,99999);		
	}

	public function checkAccount() {
		connect_db();		
		$sql = "SELECT `account` FROM `user` WHERE `account`='$this->account'";
		$result = mysql_query($sql);
		if ( $row = mysql_fetch_array($result) ) {
			return false;
		} else {
			return true;
		}		
	}
	
	public function upload(){
		connect_db();		
		if($this->checkAccount()) {		
			$sql = "INSERT INTO `web`.`user` (`account` ,`password` ,`email`)".
					"VALUES ('$this->account', '$this->password', '$this->email');" ;
			mysql_query($sql);
		} else {
			echo 'has the same account.';
		}
	}	
}

$userObj1 = new User('ggm2', '123');
$userObj1->email='ggm@gmail.com';
$userObj1->upload();

$userObj2 = new User('ggm3', null);
$userObj2->email='ggm@gmail.com';
$userObj2->upload();

echo '<pre>';
print_r($userObj1);
print_r($userObj2);
echo '</pre>';

?>
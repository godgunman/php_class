<?php

function connect_db() {
	$link = mysql_connect("localhost", "root", "root");
	mysql_query('SET NAMES utf8');
	mysql_select_db('web');
	return $link;
}


?>
<?php

require '../src/facebook.php';
require_once 'facebook_utility.php';

/* 
創造一個 Facebook 物件，填入的appID 和 secret 是從
https://developers.facebook.com/apps 這邊拿到的
*/
$facebook = new Facebook(array(
  'appId'  => '467135859978310',
  'secret' => '8bf15b2132fc8a6f703043a7d552d6e7',
));

/*
拿到 user id ，藉以判斷是否登入成功。
如果 $user 不為 null 就是登入成功
*/
$user = $facebook->getUser();


if ($user) {
  	/* 使用Facebook API 拿到使用者資訊 */
    $user_profile = $facebook->api('/me');
}

/* 
利用 Facebook 物件，拿到登入的網址和登出的網址。若使用者呈現登入的狀態
則拿登出網址，否則拿登入網址。
*/
if ($user) {
  $logoutUrl = $facebook->getLogoutUrl();
} else {
	/* 登入的同時，要求 user_status,user_photos,read_stream,publish_stream 這些權限*/
	$params = array('scope' => 'user_status,user_photos,read_stream,publish_stream');
	$loginUrl = $facebook->getLoginUrl($params);
}

/* 直接拿取 naitik 這個人的公開資訊 */
$naitik = $facebook->api('/naitik');


if ($user) {
/* 詳見 facebook_utility.php */
//	getFriends($facebook);
//	addStatues($facebook, 'php test 1234');
//	viewPhotos($facebook);
}

?>
<!doctype html>
<html xmlns:fb="http://www.facebook.com/2008/fbml">
  <head>
    <title>php-sdk</title>
    <style>
      body {
        font-family: 'Lucida Grande', Verdana, Arial, sans-serif;
      }
      h1 a {
        text-decoration: none;
        color: #3b5998;
      }
      h1 a:hover {
        text-decoration: underline;
      }
    </style>
  </head>
  <body>
    <h1>php-sdk</h1>

    <?php if ($user): ?>
      <a href="<?php echo $logoutUrl; ?>">Logout</a>
    <?php else: ?>
      <div>
        Login using OAuth 2.0 handled by the PHP SDK:
        <a href="<?php echo $loginUrl; ?>">Login with Facebook</a>
      </div>
    <?php endif ?>

    <h3>PHP Session</h3>
    <pre><?php print_r($_SESSION); ?></pre>

    <?php if ($user): ?>
      <h3>You</h3>
      <img src="https://graph.facebook.com/<?php echo $user; ?>/picture">

      <h3>Your User Object (/me)</h3>
      <pre><?php print_r($user_profile); ?></pre>
    <?php else: ?>
      <strong><em>You are not Connected.</em></strong>
    <?php endif ?>

    <h3>Public profile of Naitik</h3>
    <img src="https://graph.facebook.com/naitik/picture">
    <?php echo $naitik['name']; ?>
  </body>
</html>

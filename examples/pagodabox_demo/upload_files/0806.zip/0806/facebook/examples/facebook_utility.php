<?php
function getFriends($facebook) {
	/* 拿到使用者的朋友清單 */
	$result = $facebook->api('/me/friends');
	$data = $result['data'];
	echo '<pre>';	
	foreach($data as $sub_data) {
		$id = $sub_data['id'];
		$name = $sub_data['name'];		
		echo $name.'<br>';
		echo "<img src='https://graph.facebook.com/$id/picture'><br>";
	}	
	echo '</pre>';	
}

function addStatues($facebook, $message) {
	/* 更新動態在自己的牆上 */
	$result = $facebook->api('me/feed', 'POST', array('message'=>$message));	
	echo $result.'<br>';
}

function viewPhotos($facebook) {
	/* 拿使用者的相簿清單
	   在針對每本相簿拿裡面的照片清單
	*/
	$albums = $facebook->api('/me/albums');
	foreach ($albums['data'] as $album) {
	
		$id = $album['id'];
		$photos = $facebook->api("$id/photos");
		foreach($photos['data'] as $photo) {		
			$photo_path = $photo['source'];
			
			echo "<img src='$photo_path' /> <br>";
		}
	}
}

?>